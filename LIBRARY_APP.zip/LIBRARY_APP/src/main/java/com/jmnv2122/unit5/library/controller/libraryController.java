package com.jmnv2122.unit5.library.controller;

import com.jmnv2122.unit5.library.model.librayModel;
import com.jmnv2122.unit5.library.model.reservationsAPI;
import com.jmnv2122.unit5.library.view.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import org.json.JSONException;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


/**
 * The type Library controller.
 */
public class libraryController {

    /**
     * The Libray model.
     */
    com.jmnv2122.unit5.library.model.librayModel librayModel = new librayModel();
    /**
     * The Reservations api.
     */
    com.jmnv2122.unit5.library.model.reservationsAPI reservationsAPI = new reservationsAPI();
    /**
     * The State.
     */
    searchStatesEnum state = searchStatesEnum.SHOWUSERS;
    /**
     * The User list.
     */
    List<UsersjpaEntity> userList = new ArrayList<>();
    /**
     * The Book list.
     */
    List<BooksjpaEntity> bookList = new ArrayList<>();
    /**
     * The Lending list.
     */
    List<LendingjpaEntityFinal> lendingList = new ArrayList<>();
    /**
     * The From date.
     */
    LocalDate fromDate = LocalDate.now();
    /**
     * The To date.
     */
    LocalDate toDate = LocalDate.now().plusDays(7);
    /**
     * The Fine date.
     */
    LocalDate fineDate = LocalDate.now().plusDays(15);


    //region DECLARATIONS

    @FXML
    private GridPane bottomConfirmedLending;

    @FXML
    private ImageView acceptDownLendingOption1;

    @FXML
    private GridPane subPaneBooks;

    @FXML
    private TextField txbSearchTitleBook;

    @FXML
    private TextField txbPublisherBook;

    @FXML
    private TextField txbTitleBooks;

    @FXML
    private TextField txbSearchGetNameUser;

    @FXML
    private GridPane userPane;

    @FXML
    private TextField txbCopiesBooks;

    @FXML
    private ImageView Users;

    @FXML
    private GridPane booksPane;

    @FXML
    private ImageView LentBook;

    @FXML
    private GridPane bottomConfirmedAcctions;

    @FXML
    private GridPane txbSearchBook;

    @FXML
    private GridPane BottomPrincipalPane;

    @FXML
    private GridPane principalPaneOptions;

    @FXML
    private ImageView searchDownButton;

    @FXML
    private TextField txbCodeUsers;

    @FXML
    private ImageView addDownButton;

    @FXML
    private ImageView Books;

    @FXML
    private ImageView cancelDownOption;

    @FXML
    private ImageView Exit;

    @FXML
    private DatePicker BirthdateUsers;

    @FXML
    private ImageView ReturnBook;

    @FXML
    private ImageView editDownButton;

    @FXML
    private GridPane UserBooksPane;

    @FXML
    private ImageView searchBook;

    @FXML
    private GridPane subPaneUsers;

    @FXML
    private TextField txbSurnameUsers;

    @FXML
    private ImageView searchUser;

    @FXML
    private Label lblCodePrincipalPane;

    @FXML
    private ImageView acceptDownOption;

    @FXML
    private GridPane txbSearchUser;

    @FXML
    private TextField txbIsbnBooks;

    @FXML
    private TextField txbNameUsers;

    @FXML
    private TextField txbSearchCodeUser;

    @FXML
    private TextField txbSearchISBN;

    @FXML
    private ToggleGroup toggleGroup;

    @FXML
    private ComboBox cmbUsers;

    @FXML
    private ComboBox cmbBooks;

    @FXML
    private GridPane gpCmbUsers;

    @FXML
    private GridPane gpCmbBooks;

    @FXML
    private ImageView buttonDelete;

    //endregion

    //region PRINCIPAL UP PANEL

    /**
     * Show users to get the usability of the users tab by status.
     * Is the tab button of users.
     */

    public void showUsers(){
        userPane.setVisible(true);
        BottomPrincipalPane.setVisible(true);
        bottomConfirmedAcctions.setVisible(false);
        bottomConfirmedLending.setVisible(false);
        booksPane.setVisible(false);
        UserBooksPane.setVisible(false);
        txbCodeUsers.setDisable(true);
        txbNameUsers.setDisable(true);
        txbSurnameUsers.setDisable(true);
        BirthdateUsers.setDisable(true);
        txbCodeUsers.clear();
        txbNameUsers.clear();
        txbSurnameUsers.clear();
        BirthdateUsers.setValue(null);
        Users.setStyle("-fx-effect: dropshadow(three-pass-box, #ffffff, 20, 0, 0, 0)");
        Books.setStyle(null);
        LentBook.setStyle(null);
        ReturnBook.setStyle(null);
        Users.setScaleX(1.2);
        Users.setScaleY(1.2);
        Books.setScaleX(1);
        Books.setScaleY(1);
        LentBook.setScaleX(1);
        LentBook.setScaleY(1);
        ReturnBook.setScaleX(1);
        ReturnBook.setScaleY(1);
        state = searchStatesEnum.SHOWUSERS;
    }

    /**
     * Show nooks to get the usability of the nooks tab by status.
     * Is the tab button of books.
     */

    public void showBooks(){
        Users.setEffect(null);
        Users.setStyle(null);
        LentBook.setStyle(null);
        ReturnBook.setStyle(null);
        Users.setScaleX(1);
        Users.setScaleY(1);
        Books.setStyle("-fx-effect: dropshadow(three-pass-box, #ffffff, 20, 0, 0, 0)");
        Books.setScaleX(1.2);
        Books.setScaleY(1.2);
        LentBook.setScaleX(1);
        LentBook.setScaleY(1);
        ReturnBook.setScaleX(1);
        ReturnBook.setScaleY(1);
        userPane.setVisible(false);
        userPane.isDisable();
        BottomPrincipalPane.setVisible(true);
        bottomConfirmedAcctions.setVisible(false);
        bottomConfirmedLending.setVisible(false);
        booksPane.setVisible(true);
        UserBooksPane.setVisible(false);
        txbIsbnBooks.setDisable(true);
        txbTitleBooks.setDisable(true);
        txbCopiesBooks.setDisable(true);
        txbPublisherBook.setDisable(true);
        txbIsbnBooks.clear();
        txbTitleBooks.clear();
        txbCopiesBooks.clear();
        txbPublisherBook.clear();
        state = searchStatesEnum.SHOWBOOKS;
    }

    /**
     * Show lent books to get the usability of the lends tab by status.
     * Is the tab button of lent books.
     */

    public void showLentBooks(){
        Users.setScaleX(1);
        Users.setScaleY(1);
        Users.setEffect(null);
        Users.setStyle(null);
        Books.setStyle(null);
        ReturnBook.setStyle(null);
        Books.setScaleX(1);
        Books.setScaleY(1);
        LentBook.setStyle("-fx-effect: dropshadow(three-pass-box, #ffffff, 20, 0, 0, 0)");
        LentBook.setScaleX(1.2);
        LentBook.setScaleY(1.2);
        ReturnBook.setScaleX(1);
        ReturnBook.setScaleY(1);
        userPane.setVisible(false);
        bottomConfirmedLending.setVisible(true);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(false);
        booksPane.setVisible(false);
        UserBooksPane.setVisible(true);
        txbSearchGetNameUser.clear();
        txbSearchTitleBook.clear();
        txbSearchCodeUser.clear();
        txbSearchISBN.clear();
        cmbUsers.setVisible(false);
        cmbBooks.setVisible(false);
        txbSearchGetNameUser.setVisible(true);
        txbSearchTitleBook.setVisible(true);
        state = searchStatesEnum.SHOWLENTBOOKS;
    }

    /**
     * Show returns books to get the usability of the return books tab by status.
     * Is the tab button of return books.
     */

    public void showReturnBooks(){
        Users.setScaleX(1);
        Users.setScaleY(1);
        Books.setScaleX(1);
        Books.setScaleY(1);
        Users.setEffect(null);
        Users.setStyle(null);
        Books.setStyle(null);
        LentBook.setStyle(null);
        LentBook.setScaleX(1);
        LentBook.setScaleY(1);
        ReturnBook.setStyle("-fx-effect: dropshadow(three-pass-box, #ffffff, 20, 0, 0, 0)");
        ReturnBook.setScaleX(1.2);
        ReturnBook.setScaleY(1.2);
        userPane.setVisible(false);
        bottomConfirmedLending.setVisible(true);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(false);
        booksPane.setVisible(false);
        UserBooksPane.setVisible(true);
        txbSearchGetNameUser.clear();
        txbSearchTitleBook.clear();
        txbSearchCodeUser.clear();
        txbSearchISBN.clear();
        cmbUsers.setVisible(false);
        cmbBooks.setVisible(false);
        txbSearchGetNameUser.setVisible(true);
        txbSearchTitleBook.setVisible(true);
        state = searchStatesEnum.SHOWRETURNBOOKS;
    }

    /**
     * Show exit is the tab button of Exit.
     */

    public void exit(){
        Platform.exit();
    }

    //endregion

    //region USER VIEW FUNCTIONS

    /**
     * Show add users to get the usability of the users tab by status.
     * Is the button for add the users.
     */

    public void addUser(){
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        UserBooksPane.setVisible(false);
        txbCodeUsers.setDisable(false);
        txbNameUsers.setDisable(false);
        txbSurnameUsers.setDisable(false);
        BirthdateUsers.setDisable(false);
        state = searchStatesEnum.ADDUSER;
    }

    /**
     * Show search users to get the usability of the users tab by status.
     * Is the button for add the search users.
     */

    public void searchUser() {
        userPane.setVisible(true);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        txbCodeUsers.setDisable(false);
        txbNameUsers.setDisable(true);
        txbSurnameUsers.setDisable(true);
        BirthdateUsers.setDisable(true);
        state = searchStatesEnum.SEARCHUSERFORCODE;
    }

    /**
     * Show edit users to get the usability of the users tab by status.
     * Is the button for edit the users.
     */

    public void editUser(){
        userPane.setVisible(true);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        booksPane.setVisible(false);
        UserBooksPane.setVisible(false);
        txbCodeUsers.setDisable(false);
        txbNameUsers.setDisable(true);
        txbSurnameUsers.setDisable(true);
        BirthdateUsers.setDisable(true);
        state = searchStatesEnum.UPDATEUSER;
    }

    /**
     * Show search users to get the usability of the users tab by status.
     * Is the button for add the search users.
     */

    public void deleteUsers() {
        userPane.setVisible(true);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        txbCodeUsers.setDisable(false);
        txbNameUsers.setDisable(true);
        txbSurnameUsers.setDisable(true);
        BirthdateUsers.setDisable(true);
        state = searchStatesEnum.DELETEUSER;
    }

    //endregion

    //region BOOKS VIEW FUNCTIONS

    /**
     * Show add books to get the usability of the books tab by status.
     * Is the button for add the books.
     */

    public void addBook(){
        booksPane.setVisible(true);
        userPane.setVisible(false);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        UserBooksPane.setVisible(false);
        txbIsbnBooks.setDisable(false);
        txbTitleBooks.setDisable(false);
        txbCopiesBooks.setDisable(false);
        txbPublisherBook.setDisable(false);
        state = searchStatesEnum.ADDBOOK;
    }

    /**
     * Show search books to get the usability of the books tab by status.
     * Is the button for search the books.
     */

    public void searchBook() {
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        userPane.setVisible(false);
        booksPane.setVisible(true);
        txbIsbnBooks.setDisable(false);
        txbTitleBooks.setDisable(true);
        txbCopiesBooks.setDisable(true);
        txbPublisherBook.setDisable(true);
        state = searchStatesEnum.SEARCHBOOK;
    }

    /**
     * Show edit books to get the usability of the books tab by status.
     * Is the button for edit books.
     */

    public void editBook(){
        userPane.setVisible(false);
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        booksPane.setVisible(true);
        txbIsbnBooks.setDisable(false);
        txbTitleBooks.setDisable(true);
        txbCopiesBooks.setDisable(true);
        txbPublisherBook.setDisable(true);
        state = searchStatesEnum.UPDATEBOOK;
    }

    public void deleteBooks() {
        BottomPrincipalPane.setVisible(false);
        bottomConfirmedAcctions.setVisible(true);
        userPane.setVisible(false);
        booksPane.setVisible(true);
        txbIsbnBooks.setDisable(false);
        txbTitleBooks.setDisable(true);
        txbCopiesBooks.setDisable(true);
        txbPublisherBook.setDisable(true);
        state = searchStatesEnum.DELETEBOOK;
    }

    //endregion

    //region BUTTONS ADD, SEARCH, UPDATE, AND DELETE, CONFIRM AND CANCEL OF BOTTOM OPTIONS

    /**
     * Button add to add users or add books.
     */

    public void buttonAdd(){
        if(state == searchStatesEnum.SHOWUSERS){
            addUser();
        }
        if(state == searchStatesEnum.SHOWBOOKS){
            addBook();
        }
    }

    /**
     * Button search to search users or search books.
     */

    public void buttonSearch(){
        if(state == searchStatesEnum.SHOWUSERS){
            searchUser();
        }
        if(state == searchStatesEnum.SHOWBOOKS){
            searchBook();
        }
    }

    /**
     * Button update for update users or search books.
     */

    public void buttonUpdate(){
        if(state == searchStatesEnum.SHOWUSERS){
            editUser();
        }
        if(state == searchStatesEnum.SHOWBOOKS){
            editBook();
        }
    }

    /**
     * Button delete for delete users or books.
     */

    public void buttonDelete(){
        if(state == searchStatesEnum.SHOWUSERS){
            deleteUsers();
        }
        if(state == searchStatesEnum.SHOWBOOKS){
            deleteBooks();
        }
    }

    /**
     * Button confirmed to confirmed all functions by state.
     *
     * @throws Exception the exception
     */

    public void buttonConfirmed() throws Exception {
        switch(state){
            case ADDUSER:
                insertUser();
                break;
            case SEARCHUSERFORCODE:
                searchUserForCode();
                break;
            case UPDATEUSER:
                updateUser();
                break;
            case INSERTUPDATEUSER:
                insertUpdateUser();
                break;
            case DELETEUSER:
                deleteUser();
                break;
            case ADDBOOK:
                insertBook();
                break;
            case SEARCHBOOK:
                searchBookForIsbn();
                break;
            case UPDATEBOOK:
                updateBook();
                break;
            case INSERTUPDATEBOOK:
                insertUpdateBook();
                break;
            case DELETEBOOK:
                deleteBook();
                break;
            default: break;
        }
    }

    /**
     * Button cancel to cancel all functions by state.
     */

    public void buttonCancel(){
        switch(state){
            case ADDUSER:
                showUsers();
                break;
            case SEARCHUSERFORCODE:
                showUsers();
                break;
            case UPDATEUSER:
                showUsers();
                break;
            case INSERTUPDATEUSER:
                showUsers();
                break;
            case DELETEUSER:
                showUsers();
                break;
            case ADDBOOK:
                showBooks();
                break;
            case SEARCHBOOK:
                showBooks();
                break;
            case UPDATEBOOK:
                showBooks();
                break;
            case INSERTUPDATEBOOK:
                showBooks();
                break;
            case DELETEBOOK:
                showBooks();
                break;
            default: break;
        }
    }

    //endregion

    //region BUTTONS SEARCH USER AND BOOKS

    /**
     * Button search user to search the user in lendings and returns.
     */

    public void buttonSearchUser(){
        try{
            userList = (librayModel.checkCodeByUserSurname(txbSearchGetNameUser.getText()));
            if(userList.size() == 1){
                for (Object user : userList) {
                    UsersjpaEntity usersList = (UsersjpaEntity) user;
                    txbSearchGetNameUser.clear();
                    txbSearchCodeUser.setText(usersList.getCode());
                    txbSearchGetNameUser.setText(usersList.getName() + " " + usersList.getSurname());
                }
            }else if(userList.isEmpty()) {
                showAlertError("The user not exists.");
                cmbUsers.setVisible(false);
                txbSearchCodeUser.clear();
                txbSearchGetNameUser.setVisible(true);
                txbSearchGetNameUser.clear();
            }else{
                cmbUsers.getItems().clear();
                txbSearchGetNameUser.setVisible(false);
                gpCmbUsers.setVisible(true);
                cmbUsers.setVisible(true);
                cmbUsers.getItems().addAll(FXCollections.observableList(userList));
            }
        } catch (Exception e) {
            showAlertInformation("Reset the comboboxes");
        }
    }

    /**
     * Button search book to search the book in lendings and returns.
     */

    public void buttonSearchBook(){
        try{
            bookList = (librayModel.checkIsbnByTitleBook(txbSearchTitleBook.getText()));
            if(bookList.size() == 1){
                for(Object book : bookList){
                    BooksjpaEntity booksList = (BooksjpaEntity) book;
                    txbSearchTitleBook.clear();
                    txbSearchISBN.setText(booksList.getIsbn());
                    txbSearchTitleBook.setText(booksList.getTitle());
                }
            }else if(bookList.isEmpty()) {
                showAlertError("The book not exists.");
                gpCmbBooks.setVisible(false);
                cmbBooks.setVisible(false);
                txbSearchISBN.clear();
                txbSearchTitleBook.setVisible(true);
                txbSearchTitleBook.clear();
            }else{
                cmbBooks.getItems().clear();
                txbSearchTitleBook.setVisible(false);
                gpCmbBooks.setVisible(true);
                cmbBooks.setVisible(true);
                cmbBooks.getItems().addAll(FXCollections.observableList(bookList));
            }
        } catch (Exception e) {
            showAlertInformation("Reset the comboboxes");
        }
    }

    //endregion

    //region BUTTON CONFIRMED TO LENDINGS AND RETURNS BOOKS

    /**
     * Button confirmed lendings and returns to confirm the lendings and returns.
     */

    public void buttonConfirmedLendingsAndReturns(){
        switch(state){
            case SHOWLENTBOOKS:
                lentBook();
                break;
            case SHOWRETURNBOOKS:
                returnBook();
                break;
            default:
                break;
        }

        txbSearchGetNameUser.clear();
        txbSearchTitleBook.clear();
        txbSearchCodeUser.clear();
        txbSearchISBN.clear();
        txbSearchGetNameUser.setVisible(true);
        txbSearchTitleBook.setVisible(true);
        txbSearchGetNameUser.clear();
        cmbUsers.getEditor().clear();
        cmbBooks.getEditor().clear();
        cmbUsers.setVisible(false);
        cmbBooks.setVisible(false);
    }

    //endregion

    //region REGION TAB 1, USERS METHODS

    /**
     * Insert user.
     */
//METHOD THAT CHECKS FOR ERRORS IN ORDER TO DO THE USER INSERTION CORRECTLY
    public void insertUser() {
        String regexCodeUser = ("^[A-Z|a-z]{1}[0-9]{1,7}$");
        String regexName = ("^[a-z| |A-Z]{1,25}$");
        try {
            if (librayModel.checkCodeUser(txbCodeUsers.getText())) {
                showAlertError("The user code exists in the data base.");
                txbCodeUsers.clear();
                return;
            }
        } catch (Exception e) {
            showAlertError(e.getCause().getCause().getMessage());
        }
        if (txbCodeUsers.getText().isBlank() || txbCodeUsers.getText().equals("")) {
            showAlertError("The user code can't be null.");
            txbCodeUsers.clear();
            return;
        }
        if (!txbCodeUsers.getText().matches(regexCodeUser)){
            showAlertError("The user code inserted is not correctly, the format is 'A0000000' and MAX 8 charecters!");
            return;
        }
        if (txbNameUsers.getText().equals("") || txbNameUsers.getText().isBlank()) {
            showAlertError("The name field can't be null");
            return;
        }
        if (!txbNameUsers.getText().matches(regexName)) {
            showAlertError("The name field can't be more than 25 charecters.");
            return;
        }
        if (txbSurnameUsers.getText().equals("") || txbSurnameUsers.getText().isBlank()) {
            showAlertError("The surname field can't be null");
            return;
        }
        if (!txbSurnameUsers.getText().matches(regexName)) {
            showAlertError("The surname field can't be more than 25 charecters.");
            return;
        }
        if(BirthdateUsers.getEditor().equals("") || BirthdateUsers.getEditor().getText().isBlank()) {
            showAlertError("The field Birthdate can't be null.");
            return;
        }
        if(BirthdateUsers.getValue().compareTo(fromDate) > 0){
            showAlertError("The date of birth cannot be later than the current date of birth.");
            return;
        }else{
            try{
                showAlertInformation("User inserted correctly!");
                librayModel.insertUser(txbCodeUsers.getText(), txbNameUsers.getText(), txbSurnameUsers.getText(), Date.valueOf(BirthdateUsers.getValue()));
                showUsers();
            } catch (Exception e) {
                showAlertError(e.getCause().getCause().getMessage());
            }

        }
    }

    /**
     * Search user for code.
     */
//METHOD THAT CHECKS FOR ERRORS IN ORDER TO DO THE SEARCH USER CORRECTLY
    public void searchUserForCode() {
        try{
            if(!librayModel.checkCodeUser(txbCodeUsers.getText())){
                showAlertError("The user code not exist in the data base or the field is empty.");
                txbCodeUsers.clear();
            }else{
                UsersjpaEntity userEntity = librayModel.searchUserByCode(txbCodeUsers.getText());
                txbNameUsers.setText(userEntity.getName());
                txbSurnameUsers.setText(userEntity.getSurname());
                BirthdateUsers.setValue(userEntity.getBirthdate().toLocalDate());
            }
        }catch (Exception e){
            showAlertError(e.getCause().getCause().getMessage());
        }
    }

    /**
     * Update user.
     */
//METHOD FOR CHECK THE USER IN THE UPDATE
    public void updateUser(){
        try{
            if(!librayModel.checkCodeUser(txbCodeUsers.getText())){
                showAlertError("The user code not exist in the data base or the field is empty.");
                txbCodeUsers.clear();
            }else {
                UsersjpaEntity userEntity = librayModel.searchUserByCode(txbCodeUsers.getText());
                txbCodeUsers.setDisable(true);
                txbNameUsers.setDisable(false);
                txbSurnameUsers.setDisable(false);
                BirthdateUsers.setDisable(false);
                txbNameUsers.setText(userEntity.getName());
                txbSurnameUsers.setText(userEntity.getSurname());
                BirthdateUsers.setValue(userEntity.getBirthdate().toLocalDate());
                state = searchStatesEnum.INSERTUPDATEUSER;
            }
        }catch(Exception e){
            showAlertError(e.getCause().getCause().getMessage());
        }
    }

    /**
     * Insert update user.
     */
//METHOD FOR UPDATED AFTER THE CHECK OF THE CODE USER
    public void insertUpdateUser() {
        String regexName = ("^[a-z|ñ| |A-Z]{1,25}$");
        if (txbNameUsers.getText().equals("") || txbNameUsers.getText().isBlank()) {
            showAlertError("The name field can't be null");
            return;
        }
        if (!txbNameUsers.getText().matches(regexName)) {
            showAlertError("The name field can't be more than 25 charecters.");
            return;
        }
        if (txbSurnameUsers.getText().equals("") || txbSurnameUsers.getText().isBlank()) {
            showAlertError("The surname field can't be null");
            return;
        }
        if (!txbSurnameUsers.getText().matches(regexName)) {
            showAlertError("The surname field can't be more than 25 charecters.");
            return;
        }
        if(BirthdateUsers.getValue().compareTo(fromDate) > 0){
            showAlertError("The date of birth cannot be later than the current date of birth.");
            return;
        }
        if(BirthdateUsers.getEditor().equals("") || BirthdateUsers.getEditor().getText().isBlank()) {
            showAlertError("The field Birthdate can't be null.");
            return;
        }else{
            try{
                librayModel.updateUsersByCode(txbCodeUsers.getText(), txbNameUsers.getText(), txbSurnameUsers.getText(), Date.valueOf(BirthdateUsers.getValue()));
                showAlertConfirmed("Update successfully!");
                showUsers();
                state = searchStatesEnum.SHOWUSERS;
            } catch (Exception e) {
                showAlertError(e.getCause().getCause().getMessage());
            }
        }
    }

    public void deleteUser(){
        try{
            if(!librayModel.checkCodeUser(txbCodeUsers.getText())){
                showAlertError("The user code not exist in the data base or the field is empty.");
                txbCodeUsers.clear();
            }else{
                showAlertDeleteUsers(txbCodeUsers.getText());
            }
        }catch (Exception e){
            showAlertError(e.getCause().getCause().getMessage());
        }
    }

    public void showAlertDeleteUsers(String codeUser){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete User.");
        alert.setHeaderText(null);
        alert.setContentText("Would you like to delete the User?");
        Optional<ButtonType> button = alert.showAndWait();
        if(button.get() == ButtonType.OK){
            try {
                if(librayModel.lendingBorrower(txbCodeUsers.getText()) == null){
                    showAlertWarning("This user cannot be deleted because he/she has pending lendings.");
                    return;
                }else if(reservationsAPI.getRequestUser(codeUser)){
                    showAlertWarning("This user cannot be deleted because he/she has pending reservations.");
                }
                else{
                    librayModel.deleteUsersByCode(txbCodeUsers.getText());
                    showAlertInformation("User deleted correctly!");
                    txbCodeUsers.clear();
                    txbCodeUsers.setDisable(true);
                }
            } catch (IOException | JSONException e) {
                showAlertError(e.getCause().getCause().getMessage());
            } catch (Exception e) {
                showAlertError(e.getCause().getMessage());
            }
        }
    }

    //endregion

    //region REGION TAB 2, BOOKS METHODS

    /**
     * Insert book.
     */
//METHOD FOR INSERT BOOKS
    public void insertBook(){
        String regexIsbn = ("^[0-9]{13}$");
        String regexTitle = ("^[a-z| |A-Z]{1,90}$");
        String regexCoipes = ("^[0-9]+$");
        String regexPublisher = ("^[a-z| |A-Z]{1,60}$");
        try {
            if(librayModel.checkIsbnBook(txbIsbnBooks.getText())){
                showAlertError("The ISBN exists in the data base.");
                txbIsbnBooks.clear();
                return;
            }
        } catch (Exception e) {
            showAlertError("The isbn not exists in the data base.");
        }
        if(txbIsbnBooks.getText().isBlank() || txbIsbnBooks.getText().equals("")){
            showAlertError("The ISBN can't be null.");
            txbIsbnBooks.clear();
            return;
        }
        if(!txbIsbnBooks.getText().matches(regexIsbn)){
            showAlertError("The format of ISBN is not correctly, the correct format is the 13 integers.");
            return;
        }
        if(txbTitleBooks.getText().equals("") || txbTitleBooks.getText().isBlank()){
            showAlertError("The field title can't be null");
            return;
        }
        if(!txbTitleBooks.getText().matches(regexTitle)){
            showAlertError("The maximum length of the title field is 90 characters.");
            return;
        }
        if(txbCopiesBooks.getText().equals("") || txbCopiesBooks.getText().isBlank()){
            showAlertError("The fields Copies can't be null");
            return;
        }
        if(!txbCopiesBooks.getText().matches(regexCoipes)){
            showAlertError("The fields Copies must have a number");
            return;
        }
        if (txbPublisherBook.getText().equals("") || txbPublisherBook.getText().isBlank()){
            showAlertError("The field publisher can't be null");
            return;
        }
        if (!txbPublisherBook.getText().matches(regexPublisher)){
            showAlertError("The maximum length of the publisher field is 60 characters.");
            return;
        } else{
            try{
                showAlertInformation("Book insert correctly!");
                librayModel.insertBook(txbIsbnBooks.getText(), txbTitleBooks.getText(), Integer.valueOf(txbCopiesBooks.getText()), txbPublisherBook.getText());
                showBooks();
                state = searchStatesEnum.SHOWBOOKS;
            } catch (Exception e) {
                showAlertError("The ISBN exists in the data base or is null.");
            }
        }
    }

    /**
     * Search book for isbn.
     */
//METHOD THAT CHECKS FOR ERRORS IN ORDER TO THE SEARCH BOOKS CORRECTLY
    public void searchBookForIsbn() {
        try{
            BooksjpaEntity bookEntity = librayModel.searchBookByCode(txbIsbnBooks.getText());
            txbTitleBooks.setText(bookEntity.getTitle());
            txbCopiesBooks.setText(bookEntity.getCopies().toString());
            txbPublisherBook.setText(bookEntity.getPublisher());
        } catch (Exception e) {
            showAlertError("The ISBN not exists in the data base or is null.");
        }
    }

    /**
     * Update book.
     */
//METHOD FOR CHECK THE BOOK IN THE UPDATE
    public void updateBook(){
        try{
            if(!librayModel.checkIsbnBook(txbIsbnBooks.getText())) {
                showAlertError("The ISBN not exists in the data base or is null.");
                txbIsbnBooks.clear();
            }else{
                BooksjpaEntity bookEntity = librayModel.searchBookByCode(txbIsbnBooks.getText());
                txbIsbnBooks.setDisable(true);
                txbTitleBooks.setDisable(false);
                txbCopiesBooks.setDisable(false);
                txbPublisherBook.setDisable(false);
                txbTitleBooks.setText(bookEntity.getTitle());
                txbCopiesBooks.setText(bookEntity.getCopies().toString());
                txbPublisherBook.setText(bookEntity.getPublisher());
                state = searchStatesEnum.INSERTUPDATEBOOK;
            }
        } catch (Exception e) {
            showAlertError("The ISBN not exists in the data base or is null.");
        }
    }

    /**
     * Insert update book.
     */
//METHOD FOR UPDATED AFTER THE CHECK OF THE ISBN BOOK
    public void insertUpdateBook(){
        String regexTitle = ("^[a-z| |A-Z]{1,90}$");
        String regexCoipes = ("^[0-9]+$");
        String regexPublisher = ("^[a-z| |A-Z]{1,60}$");
        if(txbTitleBooks.getText().equals("") || txbTitleBooks.getText().isBlank()){
            showAlertError("The field title can't be null");
            return;
        }
        if(!txbTitleBooks.getText().matches(regexTitle)){
            showAlertError("The maximum length of the title field is 90 characters.");
            return;
        }
        if(txbCopiesBooks.getText().equals("") || txbCopiesBooks.getText().isBlank()){
            showAlertError("The fields Copies can't be null");
            return;
        }
        if(!txbCopiesBooks.getText().matches(regexCoipes)){
            showAlertError("The fields Copies must have a number");
            return;
        }
        if (txbPublisherBook.getText().equals("") || txbPublisherBook.getText().isBlank()){
            showAlertError("The field publisher can't be null");
            return;
        }
        if (!txbPublisherBook.getText().matches(regexPublisher)){
            showAlertError("The maximum length of the publisher field is 60 characters.");
            return;
        }else{
            try {
                librayModel.updateBooksByCode(txbIsbnBooks.getText(), txbTitleBooks.getText(), Integer.parseInt(txbCopiesBooks.getText()), txbPublisherBook.getText());
                showAlertInformation("Book Updated correctly!");
                showBooks();
                state = searchStatesEnum.SHOWBOOKS;
            } catch (Exception e) {
                showAlertError("Error.");
            }
        }
    }

    public void deleteBook(){
        try{
            if(!librayModel.checkIsbnBook(txbIsbnBooks.getText())) {
                showAlertError("The ISBN not exists in the data base or is null.");
                txbIsbnBooks.clear();
            }else{
               showAlertDeleteBooks(txbIsbnBooks.getText());
            }
        } catch (Exception e) {
            showAlertError(e.getCause().getCause().getMessage());
        }
    }

    public boolean showAlertDeleteBooks(String isbn){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Book.");
        alert.setHeaderText(null);
        alert.setContentText("Would you like to delete this book?");
        Optional<ButtonType> button = alert.showAndWait();
        if(button.get() == ButtonType.OK){
            try {
                if(!librayModel.checkLendingBook(txbIsbnBooks.getText())){
                    showAlertWarning("This book cannot be deleted because he/she has pending lendings.");
                }else if(reservationsAPI.getRequestIsReserved(txbIsbnBooks.getText())){
                    showAlertWarning("This book cannot be deleted because he/she has pending reservations.");
                }
                else{
                    reservationsAPI.deleteBookRequest(isbn);
                    showAlertInformation("Book deleted correctly!");
                    txbIsbnBooks.clear();
                    txbIsbnBooks.setDisable(true);
                }
            } catch (IOException | JSONException e) {
                showAlertError(e.getCause().getCause().getMessage());
            } catch (Exception e) {
                showAlertError(e.getCause().getMessage());
            }
        }
        return true;
    }

    //endregion

    //region LENTBOOKS TAB 3

    /**
     * Cmb users on change to insert the code in the text field of the user code and the user name.
     */

    public void cmbUsersOnChange(){
        try{
            UsersjpaEntity user = (UsersjpaEntity) cmbUsers.getSelectionModel().getSelectedItem();
            txbSearchCodeUser.clear();
            txbSearchCodeUser.setText(user.getCode());
            txbSearchGetNameUser.setVisible(true);
            txbSearchGetNameUser.setText(user.getName() + " " + user.getSurname());
            cmbUsers.getSelectionModel().clearSelection();
            cmbUsers.setVisible(false);
        } catch (Exception e) {
            showAlertInformation("Reset the comboboxes");
        }

    }

    /**
     * Cmb books on change to insert the isbn in the text field of isbn book and the title book.
     */

    public void cmbBooksOnChange(){
        try{
            BooksjpaEntity book = (BooksjpaEntity) cmbBooks.getSelectionModel().getSelectedItem();
            txbSearchISBN.clear();
            txbSearchISBN.setText(book.getIsbn());
            txbSearchTitleBook.setVisible(true);
            txbSearchTitleBook.setText(book.getTitle());
            cmbBooks.getSelectionModel().clearSelection();
            cmbBooks.setVisible(false);

        } catch (Exception e) {
            showAlertInformation("Reset the comboboxes");
        }
    }

    /**
     * Lent book to insert th lendings after checks the issues.
     */

    public void lentBook(){
        try {
            UsersjpaEntityFinal borrower = librayModel.lendingBorrower(txbSearchCodeUser.getText());   //OBJETO DEL USUARIO
            BooksjpaEntityFinal book = librayModel.checkBook(txbSearchISBN.getText());   //OBJETO DEL LIBRO
            if(txbSearchCodeUser.getText().isBlank() || txbSearchISBN.getText().isBlank()) {
                showAlertError("You must choose correctly the two fields.");
                return;
            }
            if(borrower.getFined() != null){   //COMPRUEBA QUE EL USUARIO NO ESTÉ MULTADO PARA EVITAR QUE PUEDA COGER LIBROS
                LocalDate finedDate = borrower.getFined().toLocalDate();
                LocalDate day = finedDate.plusDays(15);
                if(day.compareTo(finedDate) < 0){
                    showAlertError("The user has been fined, he will not be able to lent books until the  " + borrower.getFined().toString() + ".");
                    return;
                }else{
                    librayModel.deleteFined(borrower.getCode());
                    showAlertInformation("The user's fine has expired, he/she can now lend books again.");
                }
            }
            if(librayModel.checkDuplicityOfUserLending(borrower, book)){   //SI EL USUARIO TIENE O NO PRESTADO EL MISMO LIBRO
                showAlertError("The borrower already has this book on loan.");
                return;
            }else if(librayModel.checkCountLendignsForUser(borrower)){   //EVITA QUE EL USUARIO TOME MAS DE 3 LIBROS EN PRESTAMO
                showAlertError("The reader may not have more than three books on loan.");
                return;
            }else if(reservationsAPI.getRequestIsReserved(book.getIsbn()) && book.getCopies() <= 1) {  //COMPRUEBA SI HAY RESERVAS PENDIENTES DEL LIBRO QUE QUIERE TOMAR
                if((reservationsAPI.getRequestUser(borrower.getCode(), book.getIsbn()))){   // SI LAS HAY, COMPRUEBA SI HAY ALGUNA A SU NOMBRE PARA ESE LIBRO
                    String idReservation = reservationsAPI.getRequestCodeReservation(borrower.getCode(), book.getIsbn());
                    showAlertDialogReservDeleteReservation(borrower, book.getIsbn(), idReservation);
                    //PREGUNTA SI SE LO QUIERE LLEVAR, SI ELIGE SI, LLAMADA Al METODO PARA DESCONTAR UNO A LIBRO Y ELIMINAR RESERVA, SI DICE NO, PREGUNTAR SI QUIERE DECLINAR LA RESERVA
                    return;
                } else{
                    showAlertError("The book cannot be lent because it has reservations.");
                    return;
                }
            }else if(book.getCopies() > 0){
                librayModel.insertLending(borrower, txbSearchISBN.getText(), Date.valueOf(fromDate));  //SI NO HAY RESERVAS Y LAS COPIAS SON MAS QUE 0, HACE EL PRÉSTAMO
                showAlertConfirmed("Loan successfully completed");
            }else{
                showAlertDialogReservation(borrower, book.getIsbn(), Date.valueOf(fromDate));   //SI NO HAY RESERVAS Y LAS COPIAS SON 0, SE REALIZA LA RESERVA
            }
        } catch (Exception e) {
            showAlertError("The user trying to borrow the book cannot do so because it is currently pending return.");
        }
    }

    /**
     * Show alert dialog reserv delete reservation for the user to take the reservation or decline it.
     *
     * @param borrower the users jpa entity final borrower
     * @param isbn     the String isbn
     * @param id       the String id
     */

    public void showAlertDialogReservDeleteReservation(UsersjpaEntityFinal borrower, String isbn, String id){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Reservations");
        alert.setHeaderText(null);
        alert.setContentText("The user has the book reserved and is at the top of the list, do you want to borrow it?");
        Optional<ButtonType> button = alert.showAndWait();
        if(button.get() == ButtonType.OK){
            try {
                reservationsAPI.deleteRequest(id);
                librayModel.insertLending(borrower, isbn, Date.valueOf(fromDate));
                showAlertInformation("The book has been successfully reserved.");
            } catch (Exception e) {
                showAlertError(e.getCause().getCause().getCause().getMessage());
            }
        }else if(button.get() == ButtonType.CANCEL){
            Alert alert2 = new Alert(Alert.AlertType.CONFIRMATION);
            alert2.setTitle("Reservations");
            alert2.setHeaderText(null);
            alert2.setContentText("Does the user want to decline the booking?");
            Optional<ButtonType> button2 = alert.showAndWait();
            if(button2.get() == ButtonType.OK) {
                //DELETE THE RESERVATION
                reservationsAPI.deleteRequest(id);
                showAlertInformation("The reservation has been successfully removed.");
            }
        }
    }

    /**
     * Show alert dialog reservation to offers reservation if the book is not available.
     *
     * @param borrower the user jpa entity final borrower
     * @param isbn     the String isbn
     * @param fromDate the Date from date
     */

    public void showAlertDialogReservation(UsersjpaEntityFinal borrower, String isbn, Date fromDate){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Reservation");
        alert.setHeaderText(null);
        alert.setContentText("No books available, would you like to make a reservation?");
        Optional<ButtonType> button = alert.showAndWait();
        if(button.get() == ButtonType.OK){
            try {
                showAlertInformation(reservationsAPI.postRequest(borrower, isbn, fromDate));
            } catch (IOException | JSONException e) {
                showAlertError(e.getCause().getCause().getMessage());
            }
        }
    }

    //endregion

    //region RETURNBOOK TAB 4

    /**
     * Return book to return the lending after check the issues.
     */

    public void returnBook(){
        try{
            UsersjpaEntityFinal borrower = librayModel.lendingBorrower(txbSearchCodeUser.getText());
            BooksjpaEntityFinal book = librayModel.checkBook(txbSearchISBN.getText());
            if(!librayModel.lentBookByThisUser(borrower, book)){
                showAlertError("No refund is possible because the user does not have this book on loan.");
            }else{
                if(showAlertDialogSentMail(txbSearchISBN.getText())){    //AQUI SE MUESTRA, SI HAY RESERVAS DEL LIBRO DEVUELTO, EL PRIMERO DE LA LISTA CON SUS DATOS PARA AVISARLE.
                    UsersjpaEntity user = librayModel.searchUserByCode(reservationsAPI.getRequestUserByBook(txbSearchISBN.getText()));
                    String userName = user.getName() + " " + user.getSurname();
                    showAlertConfirmed("This book has the reservation by " + userName + ", Wants to send you a text message to let you know?");
                }
                if(librayModel.checkReturningLending(txbSearchCodeUser.getText(), txbSearchISBN.getText(), Date.valueOf(fromDate), Date.valueOf(fineDate))) {
                    showAlertInformation("Book returned correctly.");
                }else{
                    showAlertWarning("The user has delivered the book after the deadline, for which he will be fined with 15 days of disqualification.");
                }
            }
        } catch (Exception e) {
            showAlertError(e.getCause().getCause().getCause().getMessage());
        }
    }

    /**
     * Show alert dialog sent mail to show the first user in the reservation list when the book is returned and there were reservations in the list.
     *
     * @param isbn the String isbn
     * @return the boolean
     */

    public boolean showAlertDialogSentMail(String isbn){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Return lending.");
        alert.setHeaderText(null);
        alert.setContentText("Would you like to return this book?");
        Optional<ButtonType> button = alert.showAndWait();
        if(button.get() == ButtonType.OK){
            try {
                if(reservationsAPI.getRequestUserByBook(isbn) == null){
                    return false;
                }
            } catch (IOException | JSONException e) {
                showAlertError(e.getCause().getCause().getMessage());
            } catch (Exception e) {
                showAlertError(e.getCause().getMessage());
            }
        }
        return true;
    }

    //endregion

    //region SHOW ALERTS

    /**
     * Show alert information.
     *
     * @param error the String message
     */
    @FXML
    private void showAlertError(String error) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText(error);
        alert.showAndWait();
    }

    /**
     * Show alert information.
     *
     * @param message the String message
     */
    @FXML
    private void showAlertConfirmed(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Show alert information.
     *
     * @param message the String message
     */
    @FXML
    private void showAlertWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Show alert information.
     *
     * @param message the String message
     */
    @FXML
    public void showAlertInformation(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //endregion
}

