package com.jmnv2122.unit5.library.view;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "books", schema = "public", catalog = "library")
public class BooksjpaEntity {
    private String isbn;
    private String title;
    private Integer copies;
    private String cover;
    private String outline;
    private String publisher;
    private List<UsersjpaEntity> borrowers;
    private List<UsersjpaEntity> borrowersReservation;

    @Id
    @Column(name = "isbn", nullable = false, length = 13)
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Basic
    @Column(name = "title", nullable = false, length = 90)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "copies", nullable = true)
    public Integer getCopies() {
        return copies;
    }

    public void setCopies(Integer copies) {
        this.copies = copies;
    }

    @Basic
    @Column(name = "cover", nullable = true, length = 255)
    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    @Basic
    @Column(name = "outline", nullable = false, length = 255)
    public String getOutline() {
        return outline;
    }

    public void setOutline(String outline) {
        this.outline = outline;
    }

    @Basic
    @Column(name = "publisher", nullable = true, length = 60)
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BooksjpaEntity that = (BooksjpaEntity) o;
        return Objects.equals(isbn, that.isbn) && Objects.equals(title, that.title) && Objects.equals(copies, that.copies) && Objects.equals(cover, that.cover) && Objects.equals(outline, that.outline) && Objects.equals(publisher, that.publisher);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isbn, title, copies, cover, outline, publisher);
    }

    @ManyToMany
    @JoinTable(name = "lending", catalog = "library", schema = "public", joinColumns = @JoinColumn(name = "book", referencedColumnName = "isbn", nullable = false), inverseJoinColumns = @JoinColumn(name = "borrower", referencedColumnName = "code", nullable = false))
    public List<UsersjpaEntity> getBorrowers() {
        return borrowers;
    }

    public void setBorrowers(List<UsersjpaEntity> borrowers) {
        this.borrowers = borrowers;
    }

    @ManyToMany
    @JoinTable(name = "reservation", catalog = "library", schema = "public", joinColumns = @JoinColumn(name = "book", referencedColumnName = "isbn", nullable = false), inverseJoinColumns = @JoinColumn(name = "borrower", referencedColumnName = "code", nullable = false))
    public List<UsersjpaEntity> getBorrowersReservation() {
        return borrowersReservation;
    }

    public void setBorrowersReservation(List<UsersjpaEntity> borrowersReservation) {
        this.borrowersReservation = borrowersReservation;
    }

    @Override
    public String toString() {
        return title + "\n";
    }
}
