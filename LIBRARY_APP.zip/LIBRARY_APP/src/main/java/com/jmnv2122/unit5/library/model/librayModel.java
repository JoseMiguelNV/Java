package com.jmnv2122.unit5.library.model;

import com.jmnv2122.unit5.library.view.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;


/**
 * The type Libray model.
 */
public class librayModel {

    /**
     * The Session factory.
     */
    SessionFactory sessionFactory;

    /**
     * Instantiates a new Libray model.
     * To initiate the connection when starting the app
     */
    public librayModel() {
        @SuppressWarnings("unused")
        org.jboss.logging.Logger logger =
                org.jboss.logging.Logger.getLogger("org.hibernate");
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    /**
     * Open session session, for use in methods attacking the database.
     *
     * @return the session
     * @throws Exception the exception
     */

    public Session openSession() throws Exception {
        Session session = sessionFactory.openSession();
        if (session == null) {
            throw new Exception("Error opening session!");
        }
        return session;
    }

    //region REGION TAB 1

    /**
     * Check code user, check if the user is in the database.
     *
     * @param codeUser the String code user
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean checkCodeUser(String codeUser) throws Exception {
        Query<UsersjpaEntity> myQuery;
        try (Session session = openSession()) {
            myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntity where lower(code) = lower('" + codeUser + "')");
            if (myQuery != null) {
                List<UsersjpaEntity> users = myQuery.list();
                for (Object user : users) {
                    UsersjpaEntity usersInDataBase = (UsersjpaEntity) user;
                    if (usersInDataBase.getCode().equals(codeUser)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Update users by code for update users.
     *
     * @param codeUser  the String code user
     * @param name      the String name
     * @param surName   the String surname
     * @param birthDate the String birthdate
     * @throws Exception the exception
     */

    public void updateUsersByCode (String codeUser, String name, String surName, Date birthDate) throws Exception{
        UsersjpaEntity userEntity = new UsersjpaEntity();
        Transaction transaction;
        try (Session session = openSession()) {
            transaction = session.beginTransaction();
            userEntity.setCode(codeUser);
            userEntity.setName(name);
            userEntity.setSurname(surName);
            userEntity.setBirthdate(birthDate);
            session.update(userEntity);
            transaction.commit();
        }
    }

    public void deleteUsersByCode (String codeUser) throws Exception{
        Query<UsersjpaEntity> myQuery;
        Transaction transaction;
        try ( Session session = openSession() ) {
            transaction = session.beginTransaction();
            myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntity where lower(code) = lower('" + codeUser + "')");
            if (myQuery != null) {
                List<UsersjpaEntity> users = myQuery.list();
                for (Object user : users) {
                    UsersjpaEntity usersInDataBase = (UsersjpaEntity) user;
                    if (usersInDataBase.getCode().equals(codeUser)) {
                        session.delete(usersInDataBase);
                        transaction.commit();
                    }
                }
            }
        }
//        UsersjpaEntity userEntity = new UsersjpaEntity();
//        Transaction transaction;
//        try (Session session = openSession()) {
//            transaction = session.beginTransaction();
//            userEntity.setCode(codeUser);
//            session.delete(userEntity);
//            transaction.commit();
//        }
    }

    /**
     * Search user by code for obtains a user object.
     *
     * @param codeUser the String code user
     * @return the usersjpa entity
     * @throws Exception the exception
     */

    public UsersjpaEntity searchUserByCode(String codeUser) throws Exception {
        UsersjpaEntity userEntity = new UsersjpaEntity();
        try (Session session = openSession()) {
            Query<UsersjpaEntity> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntity where lower(code) = lower('" + codeUser + "')");
            List<UsersjpaEntity> users = myQuery.list();
            for (Object user : users) {
                UsersjpaEntity usersInDataBase = (UsersjpaEntity) user;
                if (usersInDataBase.getCode().equals(codeUser)) {
                    userEntity = usersInDataBase;
                }
            }
            return userEntity;
        }
    }

    /**
     * Insert user for to make user insertions to the database.
     *
     * @param codeUser  the String code user
     * @param name      the String name
     * @param surName   the String surname
     * @param birthDate the Date Birth date
     * @throws Exception the exception
     */

    public void insertUser(String codeUser, String name, String surName, Date birthDate) throws Exception {
        Transaction transaction;
        try (Session session = openSession()) {
            transaction = session.beginTransaction();
            UsersjpaEntity user = new UsersjpaEntity();
            user.setCode(codeUser);
            user.setName(name);
            user.setSurname(surName);
            user.setBirthdate(birthDate);
            session.save(user);
            transaction.commit();
        }
    }

    //endregion

    //region REGION TAB 2

    /**
     * Check isbn book, check if the book is in the database.
     *
     * @param isbn the String isbn
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean checkIsbnBook(String isbn) throws Exception {
        try (Session session = openSession()) {
            Query<BooksjpaEntity> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntity where isbn = '" + isbn + "' ");
            List<BooksjpaEntity> books = myQuery.list();
            for (Object book : books) {
                BooksjpaEntity booksInDataBase = (BooksjpaEntity) book;
                if (booksInDataBase.getIsbn().equals(isbn)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * Update books by code for update books.
     *
     * @param isbn      the String isbn
     * @param title     the String title
     * @param copies    the int copies
     * @param publisher the String publisher
     * @throws Exception the exception
     */

    public void updateBooksByCode(String isbn, String title, int copies, String publisher) throws Exception {
        BooksjpaEntityFinal bookEntity = new BooksjpaEntityFinal();
        try (Session session = openSession()) {
            Query<BooksjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntityFinal where isbn = '" + isbn + "' ");
            Transaction transaction = session.beginTransaction();
            bookEntity.setIsbn(isbn);
            bookEntity.setTitle(title);
            bookEntity.setCopies(copies);
            bookEntity.setCover("");
            bookEntity.setOutline("");
            bookEntity.setPublisher(publisher);
            session.update(bookEntity);
            transaction.commit();
        }
    }

    /**
     * Search book by code for obtains a book object.
     *
     * @param isbnBook the String isbn book
     * @return the booksjpa entity
     * @throws Exception the exception
     */

    public BooksjpaEntity searchBookByCode(String isbnBook) throws Exception {
        BooksjpaEntity bookEntity = null;
        try (Session session = openSession()) {
            Query<BooksjpaEntity> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntity where isbn = '" + isbnBook + "' ");
            List<BooksjpaEntity> books = myQuery.list();
            for (Object book : books) {
                BooksjpaEntity booksInDataBase = (BooksjpaEntity) book;
                if (booksInDataBase.getIsbn().equals(isbnBook)) {
                    bookEntity = booksInDataBase;
                }
            }
            return bookEntity;
        }
    }

    /**
     * Insert book for to makes books insertions to the database.
     *
     * @param isbn      the String isbn
     * @param title     the String title
     * @param copies    the int copies
     * @param publisher the String publisher
     * @throws Exception the exception
     */

    public void insertBook(String isbn, String title, int copies, String publisher) throws Exception {
        try (Session session = openSession()) {
            Transaction transaction = session.beginTransaction();
            BooksjpaEntityFinal book = new BooksjpaEntityFinal();
            book.setIsbn(isbn);
            book.setTitle(title);
            book.setCopies(copies);
            book.setCover("");
            book.setOutline("");
            book.setPublisher(publisher);
            session.save(book);
            transaction.commit();
        }
    }

    //endregion

    //region REGION TAB 3, OBTAINS USER AND BOOK

    /**
     * Check code by user surname for obtains a user list by her surname.
     *
     * @param surname the String surname
     * @return the list
     * @throws Exception the exception
     */

    public List<UsersjpaEntity> checkCodeByUserSurname(String surname) throws Exception {
        Query<UsersjpaEntity> myQuery;
        try (Session session = openSession()) {
            myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntity where lower(surname) like lower('" + surname + "%')");
            return myQuery.list();
        }
    }

    /**
     * Check isbn by title book for obtains a book list by her title.
     *
     * @param title the String title
     * @return the list
     * @throws Exception the exception
     */

    public List<BooksjpaEntity> checkIsbnByTitleBook(String title) throws Exception {
        Query<BooksjpaEntity> myQuery;
        try (Session session = openSession()) {
            myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntity where lower(title) like lower('" + title + "%')");
            return myQuery.list();
        }
    }

    /**
     * Lent book by this user to check if the user has borrowed the book.
     *
     * @param borrower the users jpa entity final borrower
     * @param book     the books jpa entity final book
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean lentBookByThisUser(UsersjpaEntityFinal borrower, BooksjpaEntityFinal book) throws Exception {
        try (Session session = openSession()) {
            List<LendingjpaEntityFinal> lendignEntity = null;
            Query<LendingjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.LendingjpaEntityFinal");
            List<LendingjpaEntityFinal> lendings = null;
            lendings = myQuery.list();
            for (int i = 0; i < lendings.size(); i++) {
                if (lendings.get(i).getUsers().equals(borrower) && lendings.get(i).getBooks().equals(book)) {
                   return true;
                }
            }
            return false;
        }
    }


    //endregion

    //region REGION TAB 3, LENDINGS

    /**
     * Insert lending to insert the loans in the database.
     *
     * @param borrower the users jpa entity final borrower
     * @param lentBook String the lent book
     * @param fromDate the Date from date
     * @throws Exception the exception
     */

    public void insertLending(UsersjpaEntityFinal borrower, String lentBook, Date fromDate) throws Exception {
        LendingjpaEntityFinal lendignEntity = new LendingjpaEntityFinal();
        try (Session session = openSession()) {
            BooksjpaEntityFinal book = lendingBook(lentBook);
            Transaction transaction = session.beginTransaction();
            lendignEntity.setBooks(book);
            lendignEntity.setUsers(borrower);
            lendignEntity.setLendingdate(fromDate);
            session.save(lendignEntity);
            transaction.commit();
            session.close();
        }
    }

    /**
     * Check book to check the book on the database and return de object.
     *
     * @param bookIsbn the String book isbn
     * @return the booksjpa entity final
     * @throws Exception the exception
     */

    public BooksjpaEntityFinal checkBook(String bookIsbn) throws Exception {
        try (Session session = openSession()) {
            Query<BooksjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntityFinal where isbn = '" + bookIsbn + "' ");
            List<BooksjpaEntityFinal> books = myQuery.list();
            for (Object book : books) {
                BooksjpaEntityFinal bookEntity = (BooksjpaEntityFinal) book;
                if (bookEntity.getIsbn().equals(bookIsbn)) {
                    return bookEntity;
                }
            }
            return null;
        }
    }

    /**
     * Check duplicity of user lending to find out if the user already has the book.
     *
     * @param borrower the borrower user jpa entity final
     * @param bookIsbn the book isbn books jpa entity final
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean checkDuplicityOfUserLending(UsersjpaEntityFinal borrower, BooksjpaEntityFinal bookIsbn) throws Exception {
        try (Session session = openSession()) {
            Query<LendingjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.LendingjpaEntityFinal");
            List<LendingjpaEntityFinal> lendings = myQuery.list();
            for (int i = 0; i < lendings.size(); i++) {
                if (lendings.get(i).getUsers().equals(borrower) && lendings.get(i).getBooks().equals(bookIsbn)) {
                    if(lendings.get(i).getReturningdate() == null){
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /**
     * Check count lendigns for user to prevent the reader from having more than three books on loan.
     *
     * @param borrower the borrower user jpa entity final
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean checkCountLendignsForUser(UsersjpaEntityFinal borrower) throws Exception {
        try (Session session = openSession()) {
            int count = 0;
            Query<LendingjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.LendingjpaEntityFinal");
            List<LendingjpaEntityFinal> lendings = myQuery.list();
            for (int i = 0; i < lendings.size(); i++) {
                if (lendings.get(i).getUsers().equals(borrower) && lendings.get(i).getReturningdate() == null) {
                    count++;
                }
            }
            if (count == 3) {
                return true;
            }
            return false;
        }
    }

    /**
     * Lending borrower to obtains the object user by the code.
     *
     * @param borrower the String borrower
     * @return the usersjpa entity final
     * @throws Exception the exception
     */

    public UsersjpaEntityFinal lendingBorrower(String borrower) throws Exception {
        try (Session session = openSession()) {
            Query<UsersjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntityFinal where code = '" + borrower + "' ");
            UsersjpaEntityFinal userEntity = null;
            List<UsersjpaEntityFinal> users = myQuery.list();
            for (Object user : users) {
                userEntity = (UsersjpaEntityFinal) user;
                if (userEntity.getCode().equals(borrower)) {
                    return userEntity;
                }
            }
            return null;
        }
    }

    public boolean checkLendingBook(String isbn) throws Exception {
        try (Session session = openSession()) {
            Query<BooksjpaEntity> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntity where isbn = '" + isbn + "' ");
            BooksjpaEntity bookEntity = null;
            List<BooksjpaEntity> books = myQuery.list();
            for (Object book : books) {
                bookEntity = (BooksjpaEntity) book;
                if (bookEntity.getIsbn().equals(isbn)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * Lending book to obtains the object book by the isbn.
     *
     * @param bookIsbn the String book isbn
     * @return the books jpa entity final
     * @throws Exception the exception
     */

    public BooksjpaEntityFinal lendingBook(String bookIsbn) throws Exception {
        try (Session session = openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<BooksjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntityFinal where isbn = '" + bookIsbn + "' ");
            List<BooksjpaEntityFinal> books = myQuery.list();
            for (Object book : books) {
                BooksjpaEntityFinal bookEntity = (BooksjpaEntityFinal) book;
                if (bookEntity.getIsbn().equals(bookIsbn) && bookEntity.getCopies() > 0) {
                    bookEntity.setCopies(bookEntity.getCopies() - 1);
                    session.update(bookEntity);
                    transaction.commit();
                    session.close();
                    return bookEntity;
                }
            }
            return null;
        }
    }

    //endregion

    //region TAB 4, RETURNS

    /**
     * Check returning lending to check the return of the book if the user miss the date will receive a fine.
     *
     * @param borrower the String borrower
     * @param bookIsbn the String book isbn
     * @param fromDate the Date from date
     * @param fineDate the Date fine date
     * @return the boolean
     * @throws Exception the exception
     */

    public boolean checkReturningLending(String borrower, String bookIsbn, Date fromDate, Date fineDate) throws Exception {
        fineDate.toLocalDate().plusDays(15);
        try (Session session = openSession()) {
            Query<LendingjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.LendingjpaEntityFinal");
            List<LendingjpaEntityFinal> lendings = myQuery.list();
            for (int i = 0; i < lendings.size(); i++) {
                if (lendings.get(i).getUsers().getCode().equals(borrower) && lendings.get(i).getBooks().getIsbn().equals(bookIsbn) && lendings.get(i).getReturningdate() == null) {
                    LocalDate lendingDated = lendings.get(i).getLendingdate().toLocalDate();
                    LocalDate afterWeekDate = lendingDated.plusDays(7);
                    if (afterWeekDate.compareTo(fromDate.toLocalDate()) > 0) {
                        Transaction transaction = session.beginTransaction();
                        lendings.get(i).setReturningdate(fromDate);
                        session.update(lendings.get(i));
                        transaction.commit();
                        session.close();
                        addCountBook(bookIsbn);
                        return true;
                    } else {
                        fineUser(borrower, fineDate);
                        Transaction transaction = session.beginTransaction();
                        lendings.get(i).setReturningdate(fromDate);
                        session.update(lendings.get(i));
                        transaction.commit();
                        session.close();
                        addCountBook(bookIsbn);
                        return false;
                    }
                }
            }
            return false;
        }
    }

    /**
     * Fine user to fine the user for missing the return date of the book.
     *
     * @param borrower the String borrower
     * @param fineDate the Date fine date
     * @throws Exception the exception
     */

    public void fineUser(String borrower, Date fineDate) throws Exception {
        fineDate.toLocalDate();
        try (Session session = openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<UsersjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntityFinal where code = '" + borrower + "' ");
            List<UsersjpaEntityFinal> users = myQuery.list();
            for (Object user : users) {
                UsersjpaEntityFinal userEntity = (UsersjpaEntityFinal) user;
                if (userEntity.getCode().equals(borrower)) {
                    userEntity.setFined(fineDate);
                    session.update(userEntity);
                    transaction.commit();
                }
            }
        }
    }

    /**
     * Delete fined to remove the fine from the user when the time is served.
     *
     * @param borrower the String borrower
     * @throws Exception the exception
     */

    public void deleteFined(String borrower) throws Exception {
        try (Session session = openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<UsersjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.UsersjpaEntityFinal where code = '" + borrower + "' ");
            List<UsersjpaEntityFinal> users = myQuery.list();
            for (Object user : users) {
                UsersjpaEntityFinal userEntity = (UsersjpaEntityFinal) user;
                if (userEntity.getCode().equals(borrower)) {
                    userEntity.setFined(null);
                    session.update(userEntity);
                    transaction.commit();
                }
            }
        }
    }

    /**
     * Add count book to add the unit to the book when it is returned and return the object or null.
     *
     * @param bookIsbn the String book isbn
     * @return the booksjpa entity final
     * @throws Exception the exception
     */

    public BooksjpaEntityFinal addCountBook(String bookIsbn) throws Exception {
        try (Session session = openSession()) {
            Transaction transaction = session.beginTransaction();
            Query<BooksjpaEntityFinal> myQuery = session.createQuery("from com.jmnv2122.unit5.library.view.BooksjpaEntityFinal where isbn = '" + bookIsbn + "' ");
            List<BooksjpaEntityFinal> books = myQuery.list();
            for (Object book : books) {
                BooksjpaEntityFinal bookEntity = (BooksjpaEntityFinal) book;
                if (bookEntity.getIsbn().equals(bookIsbn)) {
                    bookEntity.setCopies(bookEntity.getCopies() + 1);
                    session.update(bookEntity);
                    transaction.commit();
                    return bookEntity;
                }
            }
            return null;
        }
    }

    //endregion
}

