package com.jmnv2122.unit5.library.view;

import javax.persistence.*;
import java.sql.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "users", schema = "public", catalog = "library")
public class UsersjpaEntity {
    private String code;
    private String name;
    private String surname;
    private Date birthdate;
    private List<BooksjpaEntity> lentBooks;
    private List<BooksjpaEntity> lentBookReservation;

    @Id
    @Column(name = "code", nullable = false, length = 8)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 25)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "surname", nullable = false, length = 25)
    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Basic
    @Column(name = "birthdate", nullable = true)
    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UsersjpaEntity that = (UsersjpaEntity) o;
        return Objects.equals(code, that.code) && Objects.equals(name, that.name) && Objects.equals(surname, that.surname) && Objects.equals(birthdate, that.birthdate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name, surname, birthdate);
    }

    @ManyToMany(mappedBy = "borrowers")
    public List<BooksjpaEntity> getLentBooks() {
        return lentBooks;
    }

    public void setLentBooks(List<BooksjpaEntity> lentBooks) {
        this.lentBooks = lentBooks;
    }

    @ManyToMany(mappedBy = "borrowersReservation")
    public List<BooksjpaEntity> getLentBookReservation() {
        return lentBookReservation;
    }

    public void setLentBookReservation(List<BooksjpaEntity> lentBookReservation) {
        this.lentBookReservation = lentBookReservation;
    }

    @Override
    public String toString() {
        return surname + ", " + name + "\n";
    }
}
