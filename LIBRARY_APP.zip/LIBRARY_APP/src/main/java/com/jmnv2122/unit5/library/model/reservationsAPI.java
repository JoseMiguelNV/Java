package com.jmnv2122.unit5.library.model;

import com.jmnv2122.unit5.library.view.UsersjpaEntityFinal;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.Scanner;

/**
 * The type Reservations api.
 */
public class reservationsAPI {

    /**
     * Gets request user by book to get the user code for obtains her name.
     *
     * @param isbn the String isbn
     * @return the user to the reservation
     * @throws IOException   the io exception
     * @throws JSONException the json exception
     */

    public String getRequestUserByBook(String isbn) throws IOException, JSONException {
        String code = null;
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");
        if (conn.getResponseCode() == 200) {
            Scanner scanner = new Scanner(conn.getInputStream());
            String response = scanner.useDelimiter("\\Z").next();
            scanner.close();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                if(jsonObject.get("book").equals(isbn)){
                    code = jsonObject.get("borrower").toString();
                    return code;
                }
            }
        }
        else{
            System.out.println("Connection failed.");
        }
        return null;
    }

    public boolean getRequestUser(String codeUser) throws IOException, JSONException {
        String code = null;
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");
        if (conn.getResponseCode() == 200) {
            Scanner scanner = new Scanner(conn.getInputStream());
            String response = scanner.useDelimiter("\\Z").next();
            scanner.close();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                if(jsonObject.get("borrower").equals(codeUser)){
                    return true;
                }
            }
        }
        else{
            System.out.println("Connection failed.");
        }
        return false;
    }

    /**
     * Gets request is reserved to check if th book have a reservations.
     *
     * @param isbn the String isbn
     * @return the request is reserved
     * @throws IOException   the io exception
     * @throws JSONException the json exception
     */

    public boolean getRequestIsReserved(String isbn) throws IOException, JSONException {
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");
        if (conn.getResponseCode() == 200) {
            Scanner scanner = new Scanner(conn.getInputStream());
            String response = scanner.useDelimiter("\\Z").next();
            scanner.close();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                if(jsonObject.get("book").equals(isbn)){
                    return true;
                }
            }
        }
        else{
            System.out.println("Connection failed.");
        }
        return false;
    }

    /**
     * Gets request user to check if the user has already reserved the book he is requesting.
     *
     * @param borrower the String borrower
     * @param isbn     the String isbn
     * @return the request user
     * @throws IOException   the io exception
     * @throws JSONException the json exception
     */

    public boolean getRequestUser(String borrower, String isbn) throws IOException, JSONException {
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");
        if (conn.getResponseCode() == 200) {
            Scanner scanner = new Scanner(conn.getInputStream());
            String response = scanner.useDelimiter("\\Z").next();
            scanner.close();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                if(jsonObject.get("borrower").equals(borrower) && jsonObject.get("book").equals(isbn)){
                    return true;
                }
            }
        }
        else{
            System.out.println("Connection failed.");
        }
        return false;
    }

    /**
     * Gets request code reservation to get the reservation id.
     *
     * @param borrower the String borrower
     * @param isbn     the String isbn
     * @return the request code reservation
     * @throws IOException   the io exception
     * @throws JSONException the json exception
     */

    public String getRequestCodeReservation(String borrower, String isbn) throws IOException, JSONException {
        String id = null;
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");
        if (conn.getResponseCode() == 200) {
            Scanner scanner = new Scanner(conn.getInputStream());
            String response = scanner.useDelimiter("\\Z").next();
            scanner.close();
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                if(jsonObject.get("borrower").equals(borrower) && jsonObject.get("book").equals(isbn)){
                    id = jsonObject.get("id").toString();
                }
            }
        }
        else{
            System.out.println("Connection failed.");
        }
        return id;
    }

    /**
     * Post request to insert the reservations.
     *
     * @param borrower the user jpa entity final borrower
     * @param isbn     the String isbn
     * @param fromDate the Date from date
     * @return the information string
     * @throws IOException   the io exception
     * @throws JSONException the json exception
     */

    public String postRequest(UsersjpaEntityFinal borrower, String isbn, Date fromDate) throws IOException, JSONException {
        HttpURLConnection conn = null;
        String jsonInputString = new JSONObject()
                .put("book", isbn)
                .put("borrower", borrower.getCode())
                .put("date", fromDate).toString();
        URL url = new URL("http://localhost:8080/api-rest-jmnv2122/reservations");
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; utf-8");
        conn.setRequestProperty("Accept", "application/json");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonInputString.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        if (conn.getResponseCode() == 200)
            return "The book has been successfully reserved!";
        else{
            return "book not inserted, connection error.";
        }
    }

    /**
     * Delete request to delete the reservation.
     *
     * @param id the String id
     */

    public void deleteRequest(String id){
        HttpURLConnection conn = null;
        try {
            URL url = new URL(" http://localhost:8080/api-rest-jmnv2122/reservations/" + id);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            if (conn.getResponseCode() == 200){
                System.out.println("Reservation deleted");
            }
            else
                System.out.println("Connection failed");
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
        }
        finally {
            if (conn != null)
                conn.disconnect();
        }
    }

    public void deleteBookRequest(String isbn){
        HttpURLConnection conn = null;
        try {
            URL url = new URL(" http://localhost:8080/api-rest-jmnv2122/books/" + isbn);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            if (conn.getResponseCode() == 200){
                System.out.println("Book deleted Correctly");
            }
            else
                System.out.println("Connection failed");
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
        }
        finally {
            if (conn != null)
                conn.disconnect();
        }

    }
}
