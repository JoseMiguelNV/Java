package com.jmnv2122.unit5.library.view;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "reservations", schema = "public", catalog = "Library")
public class ReservationsjpaEntityFinal {
    private int id;
    private Date date;
    private BooksjpaEntityFinal booksReservations;
    private UsersjpaEntityFinal usersReservations;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "date", nullable = true)
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReservationsjpaEntityFinal that = (ReservationsjpaEntityFinal) o;
        return id == that.id && Objects.equals(date, that.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, date);
    }

    @ManyToOne
    @JoinColumn(name = "book", referencedColumnName = "isbn")
    public BooksjpaEntityFinal getBooksReservations() {
        return booksReservations;
    }

    public void setBooksReservations(BooksjpaEntityFinal booksReservations) {
        this.booksReservations = booksReservations;
    }

    @ManyToOne
    @JoinColumn(name = "borrower", referencedColumnName = "code")
    public UsersjpaEntityFinal getUsersReservations() {
        return usersReservations;
    }

    public void setUsersReservations(UsersjpaEntityFinal usersReservations) {
        this.usersReservations = usersReservations;
    }
}
