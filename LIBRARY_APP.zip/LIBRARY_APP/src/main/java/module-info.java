module com.jmnv2122.unit5.library {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.persistence;
    requires java.sql;
    requires org.hibernate.orm.core;
    requires org.jboss.logging;
    requires java.naming;
    requires jdk.unsupported;
    requires android.json;

    opens com.jmnv2122.unit5.library to javafx.fxml;
    exports com.jmnv2122.unit5.library;
    exports com.jmnv2122.unit5.library.controller;
    opens com.jmnv2122.unit5.library.controller to javafx.fxml;
    exports com.jmnv2122.unit5.library.model;
    opens com.jmnv2122.unit5.library.model to javafx.fxml;
    exports com.jmnv2122.unit5.library.view;
    opens com.jmnv2122.unit5.library.view to javafx.fxml;

}