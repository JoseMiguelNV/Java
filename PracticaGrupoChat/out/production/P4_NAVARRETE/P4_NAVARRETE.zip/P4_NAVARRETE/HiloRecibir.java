package P4_NAVARRETE;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;

//JOSE MIGUEL NAVARRETE VERA

public class HiloRecibir implements Runnable{

    Socket hiloEntrada;
    String usuario;

    public HiloRecibir(Socket hiloEntrada, String usuario) {
        this.hiloEntrada = hiloEntrada;
        this.usuario = usuario;
    }

    @Override
    public void run() {
        String linea = "";
        try {
            InputStream entrada = hiloEntrada.getInputStream();
            DataInputStream flujoEntrada = new DataInputStream(entrada);
            linea = flujoEntrada.readUTF();
            System.out.println(linea);
        } catch (SocketException e) {
            System.out.println("Cliente desconectado");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
