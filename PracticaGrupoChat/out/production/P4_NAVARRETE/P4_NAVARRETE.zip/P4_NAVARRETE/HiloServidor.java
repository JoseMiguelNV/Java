package P4_NAVARRETE;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

//JOSE MIGUEL NAVARRETE VERA

public class HiloServidor implements Runnable{

    Socket cliente;
    ArrayList<Socket> listaClientes;

    public Socket getCliente() {
        return cliente;
    }

    public void setCliente(Socket cliente) {
        this.cliente = cliente;
    }

    public HiloServidor(Socket cliente, ArrayList<Socket> listaHilos) {
        this.cliente = cliente;
        this.listaClientes = listaHilos;
    }

    @Override
    public void run() {
        String mensaje;
        int clientesConectados = 0;
        try {
            InputStream entrada = cliente.getInputStream();
            DataInputStream flujoEntrada = new DataInputStream(entrada);
            do {
                mensaje = flujoEntrada.readUTF();
                for(Socket socket : listaClientes) {
                    if (socket != cliente) {
                        OutputStream salida = socket.getOutputStream();
                        DataOutputStream flujoSalida = new DataOutputStream(salida);
                        flujoSalida.writeUTF(mensaje);

                    }
                    if(socket == cliente){
                        if(mensaje.equals("fin")){
                            socket.close();
                            listaClientes.remove(socket);

                            //clientesConectados--;
                        }
                    }
                }
//                //Bucle para obtener el número de clientes conectados
                for(int i = 0; i < listaClientes.size(); i++) {
                    clientesConectados = i;
                }
            } while (!mensaje.equals(("fin")));
        } catch (IOException e) {
            //Mostramos mensaje de desconexión del cliente en el servidor, y refrescamos el número de clientes conectados
            System.out.println("Cliente Desconectado! Clientes conectados: " + clientesConectados);
        }
    }
}

//eliminar de la lista los sockets(clientes) desconectados