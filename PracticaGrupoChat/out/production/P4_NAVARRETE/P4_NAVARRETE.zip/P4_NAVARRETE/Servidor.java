package P4_NAVARRETE;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

//JOSE MIGUEL NAVARRETE VERA

public class Servidor {

    public static void main(String[] args) {
        //Array para guardar los sockets de los clientes
        ArrayList<Socket> listaClientes = new ArrayList<>();
        int contador = 0;
        try {
            //Se realiza la conexión con el cliente
            System.out.println("SERVIDOR");
            System.out.println("Esperando conexión de un cliente...");
            ServerSocket servidor = new ServerSocket(12345);
            while(true){
                //Se realiza una conexion por cada socket recibido del cliente y se añade a la lista de sockets 'listaClientes'
                Socket cliente = servidor.accept();
                listaClientes.add(cliente);

                //Se muestra en pantalla la cantidad de clientes que se van conectando utilizando un contador para contabilizarlos
                contador++;
                System.out.println("Cliente Conectado! Clientes conectados: " + contador);

                //Se crea el hilo 'hiloServidor' donde se pasa al hilo el socket del cliente y la lista de sockets
                HiloServidor hiloServidor = new HiloServidor(cliente, listaClientes);
                Thread socket = new Thread(hiloServidor);
                socket.start();
//                if(hiloServidor.getCliente().isClosed()){
//                    contador--;
//                    System.out.println("Clientes conectados: " + contador);
//                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

